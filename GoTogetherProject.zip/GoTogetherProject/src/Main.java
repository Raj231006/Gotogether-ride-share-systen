import java.util.Scanner;

import service.BookingService;
import service.DriverService;
import service.PassengerService;
import service.AdminService;

public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        while(true) {

            System.out.println("\n===== GoTogether Menu =====");
            System.out.println("1. Book Ride");
            System.out.println("2. View Ride Bookings");
            System.out.println("3. Cancel Booking");
            System.out.println("4. Search Available Rides");
            System.out.println("5. View Passenger Ride History");
            System.out.println("6. View All Users (Admin)");
            System.out.println("7. View All Rides (Admin)");
            System.out.println("8. Exit");

            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch(choice) {

                case 1:
                    BookingService.bookRide(sc);
                    break;

                case 2:
                    DriverService.viewBookings(sc);
                    break;

                case 3:
                    BookingService.cancelBooking(sc);
                    break;

                case 4:
                    PassengerService.searchRides(sc);
                    break;

                case 5:
                    PassengerService.viewRideHistory(sc);
                    break;

                case 6:
                    AdminService.viewAllUsers();
                    break;

                case 7:
                    AdminService.viewAllRides();
                    break;

                case 8:
                    sc.close();
                    System.out.println("Exit");
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}