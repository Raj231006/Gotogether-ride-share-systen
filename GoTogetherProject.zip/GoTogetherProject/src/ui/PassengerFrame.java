package ui;

import db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PassengerFrame {

    int passengerId;
    int selectedRideId = -1;

    public PassengerFrame(int passengerId) {

        this.passengerId = passengerId;

        JFrame frame = new JFrame("Passenger Dashboard");
        frame.setSize(500, 550);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(245, 247, 250));
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("Passenger Dashboard");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(30, 60, 114));
        title.setBounds(130, 20, 260, 30);

        JButton searchBtn = new JButton("Search Rides");
        JButton bookBtn = new JButton("Book Ride");
        JButton cancelBtn = new JButton("Cancel Booking");
        JButton historyBtn = new JButton("Ride History");
        JButton payBtn = new JButton("Make Payment");
        JButton rateBtn = new JButton("Give Rating");

        JButton buttons[] = {
            searchBtn, bookBtn, cancelBtn,
            historyBtn, payBtn, rateBtn
        };

        int y = 80;

        for(JButton b : buttons) {
            b.setBounds(140, y, 220, 45);
            b.setBackground(new Color(52, 152, 219));
            b.setForeground(Color.WHITE);
            b.setFocusPainted(false);
            b.setFont(new Font("Arial", Font.BOLD, 14));
            frame.add(b);
            y += 65;
        }

        frame.add(title);
        frame.setVisible(true);

        // SEARCH RIDES
        searchBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps = con.prepareStatement(
                    "SELECT ride_id, source_city, destination_city, available_seats, price_per_seats FROM RIDE"
                );

                ResultSet rs = ps.executeQuery();

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(
                        new String[]{"Ride ID","Source","Destination","Seats","Price"},0
                    );

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("ride_id"),
                        rs.getString("source_city"),
                        rs.getString("destination_city"),
                        rs.getInt("available_seats"),
                        rs.getDouble("price_per_seats")
                    });
                }

                JTable table = new JTable(model);

                JFrame t = new JFrame("Available Rides");
                t.add(new JScrollPane(table));
                t.setSize(500,300);
                t.setLocationRelativeTo(null);
                t.setVisible(true);

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // BOOK RIDE
        bookBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps = con.prepareStatement(
                    "SELECT ride_id, source_city, destination_city, available_seats, price_per_seats FROM RIDE"
                );

                ResultSet rs = ps.executeQuery();

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(
                        new String[]{"Ride ID","Source","Destination","Seats","Price"},0
                    );

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("ride_id"),
                        rs.getString("source_city"),
                        rs.getString("destination_city"),
                        rs.getInt("available_seats"),
                        rs.getDouble("price_per_seats")
                    });
                }

                JTable table = new JTable(model);

                int option = JOptionPane.showConfirmDialog(
                    frame,
                    new JScrollPane(table),
                    "Select Ride",
                    JOptionPane.OK_CANCEL_OPTION
                );

                if(option == JOptionPane.OK_OPTION) {

                    int row = table.getSelectedRow();

                    if(row >= 0) {

                        selectedRideId = (int) table.getValueAt(row, 0);

                        String seats = JOptionPane.showInputDialog(frame, "Enter Seats");

                        Statement st = con.createStatement();
                        ResultSet rs2 = st.executeQuery(
                            "SELECT MAX(booking_id)+1 AS next_id FROM BOOKING"
                        );

                        int bookingId = 1;

                        if(rs2.next()) {
                            bookingId = rs2.getInt("next_id");
                        }

                        PreparedStatement ps2 = con.prepareStatement(
                            "INSERT INTO BOOKING VALUES (?, ?, ?, ?, CURDATE(), 'Confirmed', ?)"
                        );

                        int s = Integer.parseInt(seats);

                        ps2.setInt(1, bookingId);
                        ps2.setInt(2, passengerId);
                        ps2.setInt(3, selectedRideId);
                        ps2.setInt(4, s);
                        ps2.setDouble(5, s * 200);

                        ps2.executeUpdate();

                        JOptionPane.showMessageDialog(frame,
                            "Booking Successful\nBooking ID: " + bookingId);
                    }
                }

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // CANCEL BOOKING
        cancelBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps =
                    con.prepareStatement("SELECT booking_id, ride_id, booking_status FROM BOOKING WHERE passenger_id=?");

                ps.setInt(1, passengerId);

                ResultSet rs = ps.executeQuery();

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(
                        new String[]{"Booking ID","Ride ID","Status"},0
                    );

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getInt("ride_id"),
                        rs.getString("booking_status")
                    });
                }

                JTable table = new JTable(model);

                int option = JOptionPane.showConfirmDialog(
                    frame,
                    new JScrollPane(table),
                    "Select Booking to Cancel",
                    JOptionPane.OK_CANCEL_OPTION
                );

                if(option == JOptionPane.OK_OPTION) {
                    int row = table.getSelectedRow();

                    if(row >= 0) {
                        int bookingId = (int) table.getValueAt(row, 0);

                        PreparedStatement ps2 =
                            con.prepareStatement(
                                "UPDATE BOOKING SET booking_status='Cancelled' WHERE booking_id=? AND passenger_id=?"
                            );

                        ps2.setInt(1, bookingId);
                        ps2.setInt(2, passengerId);
                        ps2.executeUpdate();

                        JOptionPane.showMessageDialog(frame, "Booking Cancelled");
                    }
                }

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // HISTORY
        historyBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps =
                    con.prepareStatement("SELECT booking_id, ride_id, booking_status FROM BOOKING WHERE passenger_id=?");

                ps.setInt(1, passengerId);

                ResultSet rs = ps.executeQuery();

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(
                        new String[]{"Booking ID","Ride ID","Status"},0
                    );

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getInt("ride_id"),
                        rs.getString("booking_status")
                    });
                }

                JTable table = new JTable(model);

                JFrame t = new JFrame("Ride History");
                t.add(new JScrollPane(table));
                t.setSize(450,300);
                t.setLocationRelativeTo(null);
                t.setVisible(true);

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // PAYMENT
        payBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps =
                    con.prepareStatement("SELECT booking_id, total_amount FROM BOOKING WHERE passenger_id=?");

                ps.setInt(1, passengerId);

                ResultSet rs = ps.executeQuery();

                String columns[] = {"Booking ID", "Amount"};

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(columns, 0);

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getDouble("total_amount")
                    });
                }

                JTable table = new JTable(model);

                int option = JOptionPane.showConfirmDialog(
                    frame,
                    new JScrollPane(table),
                    "Select Booking for Payment",
                    JOptionPane.OK_CANCEL_OPTION
                );

                if(option == JOptionPane.OK_OPTION) {

                    int row = table.getSelectedRow();

                    if(row >= 0) {

                        int bookingId = (int) table.getValueAt(row, 0);

                        PreparedStatement check =
                            con.prepareStatement("SELECT * FROM PAYMENT WHERE booking_id=?");

                        check.setInt(1, bookingId);

                        ResultSet checkRs = check.executeQuery();

                        if(checkRs.next()) {
                            JOptionPane.showMessageDialog(frame, "Payment already done");
                            return;
                        }

                        Statement st = con.createStatement();
                        ResultSet rs2 = st.executeQuery(
                            "SELECT MAX(payment_id)+1 AS next_id FROM PAYMENT"
                        );

                        int paymentId = 1;

                        if(rs2.next()) {
                            paymentId = rs2.getInt("next_id");
                        }

                        int rideId = 0;

                        PreparedStatement getRide =
                            con.prepareStatement("SELECT ride_id FROM BOOKING WHERE booking_id=?");

                        getRide.setInt(1, bookingId);

                        ResultSet r = getRide.executeQuery();

                        if(r.next()) {
                            rideId = r.getInt("ride_id");
                        }

                        PreparedStatement ps2 = con.prepareStatement(
                            "INSERT INTO PAYMENT VALUES (?, ?, ?, ?, CURDATE(), 'UPI', 'Success')"
                        );

                        ps2.setInt(1, paymentId);
                        ps2.setInt(2, bookingId);
                        ps2.setInt(3, passengerId);
                        ps2.setInt(4, rideId);

                        ps2.executeUpdate();

                        JOptionPane.showMessageDialog(frame,
                            "Payment Successful\nPayment ID: " + paymentId);
                    }
                }

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // RATING
        rateBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps =
                    con.prepareStatement("SELECT booking_id, ride_id FROM BOOKING WHERE passenger_id=?");

                ps.setInt(1, passengerId);

                ResultSet rs = ps.executeQuery();

                String columns[] = {"Booking ID", "Ride ID"};

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(columns, 0);

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getInt("ride_id")
                    });
                }

                JTable table = new JTable(model);

                int option = JOptionPane.showConfirmDialog(
                    frame,
                    new JScrollPane(table),
                    "Select Ride to Rate",
                    JOptionPane.OK_CANCEL_OPTION
                );

                if(option == JOptionPane.OK_OPTION) {

                    int row = table.getSelectedRow();

                    if(row >= 0) {

                        int rideId = (int) table.getValueAt(row, 1);

                        PreparedStatement check =
                            con.prepareStatement(
                                "SELECT * FROM RATING WHERE reviewer_id=? AND ride_id=?"
                            );

                        check.setInt(1, passengerId);
                        check.setInt(2, rideId);

                        ResultSet checkRs = check.executeQuery();

                        if(checkRs.next()) {
                            JOptionPane.showMessageDialog(frame, "Rating already submitted");
                            return;
                        }

                        String ratingValue =
                            JOptionPane.showInputDialog("Enter Rating (1-5)");

                        String comment =
                            JOptionPane.showInputDialog("Enter Comment");

                        Statement st = con.createStatement();
                        ResultSet rs2 = st.executeQuery(
                            "SELECT MAX(rating_id)+1 AS next_id FROM RATING"
                        );

                        int ratingId = 1;

                        if(rs2.next()) {
                            ratingId = rs2.getInt("next_id");
                        }

                        int driverId = 0;

                        PreparedStatement getDriver =
                            con.prepareStatement("SELECT driver_id FROM RIDE WHERE ride_id=?");

                        getDriver.setInt(1, rideId);

                        ResultSet r = getDriver.executeQuery();

                        if(r.next()) {
                            driverId = r.getInt("driver_id");
                        }

                        PreparedStatement ps2 = con.prepareStatement(
                            "INSERT INTO RATING VALUES (?, ?, ?, ?, ?, ?)"
                        );

                        ps2.setInt(1, ratingId);
                        ps2.setInt(2, passengerId);
                        ps2.setInt(3, driverId);
                        ps2.setInt(4, rideId);
                        ps2.setInt(5, Integer.parseInt(ratingValue));
                        ps2.setString(6, comment);

                        ps2.executeUpdate();

                        JOptionPane.showMessageDialog(frame, "Rating Submitted");
                    }
                }

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });
    }
}
