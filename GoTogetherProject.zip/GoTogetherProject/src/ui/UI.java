package ui;

import javax.swing.*;
import java.awt.*;

public class UI {

    public UI() {

        JFrame frame = new JFrame("GoTogether Smart Ride Sharing System");

        frame.setSize(500, 500);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(245, 247, 250));
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("GoTogether Smart Ride Sharing System");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(30, 60, 114));
        title.setBounds(60, 40, 400, 30);

        JButton driverBtn = new JButton("Driver");
        JButton passengerBtn = new JButton("Passenger");
        JButton adminBtn = new JButton("Admin");
        JButton exitBtn = new JButton("Exit");

        JButton buttons[] = {driverBtn, passengerBtn, adminBtn, exitBtn};

        int y = 130;

        for(JButton b : buttons) {
            b.setBounds(140, y, 220, 45);
            b.setBackground(new Color(52, 152, 219));
            b.setForeground(Color.WHITE);
            b.setFocusPainted(false);
            b.setFont(new Font("Arial", Font.BOLD, 14));
            y += 70;
            frame.add(b);
        }

        frame.add(title);

        // DRIVER
        driverBtn.addActionListener(e -> {
            new LoginFrame("Driver");
        });

        // PASSENGER
        passengerBtn.addActionListener(e -> {
            new LoginFrame("Passenger");
        });

        // ADMIN
        adminBtn.addActionListener(e -> {
            new LoginFrame("Admin");
        });

        // EXIT
        exitBtn.addActionListener(e -> {
            System.exit(0);
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new UI();
    }
}