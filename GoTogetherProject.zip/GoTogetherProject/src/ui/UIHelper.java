package ui;

import javax.swing.*;
import java.awt.*;

public class UIHelper {

    public static String modernInput(JFrame parent, String message) {

        JTextField field = new JTextField();

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2,1,10,10));

        JLabel label = new JLabel(message);
        label.setFont(new Font("Arial", Font.BOLD, 14));

        field.setFont(new Font("Arial", Font.PLAIN, 14));

        panel.add(label);
        panel.add(field);

        int result = JOptionPane.showConfirmDialog(
                parent,
                panel,
                "Input Required",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if(result == JOptionPane.OK_OPTION) {
            return field.getText();
        }

        return null;
    }

    public static void modernMessage(JFrame parent, String message) {

        JLabel label = new JLabel(message, SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(new Color(30, 60, 114));

        JOptionPane.showMessageDialog(parent, label);
    }

    public static JFrame modernTable(String title, JTable table) {

        JFrame frame = new JFrame(title);

        frame.add(new JScrollPane(table));
        frame.setSize(500, 300);
        frame.setLocationRelativeTo(null);

        table.setRowHeight(25);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));

        frame.setVisible(true);

        return frame;
    }
}
