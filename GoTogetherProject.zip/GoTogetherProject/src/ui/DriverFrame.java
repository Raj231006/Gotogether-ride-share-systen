package ui;

import db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DriverFrame {

    int driverId;

    public DriverFrame(int driverId) {

        this.driverId = driverId;

        JFrame frame = new JFrame("Driver Dashboard");
        frame.setSize(500, 500);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(245, 247, 250));
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("Driver Dashboard");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(30, 60, 114));
        title.setBounds(150, 20, 220, 30);

        JButton offerBtn = new JButton("Offer Ride");
        JButton viewBtn = new JButton("View Ride Bookings");
        JButton ridesBtn = new JButton("My Rides");
        JButton completeBtn = new JButton("Complete Ride");

        JButton buttons[] = {offerBtn, viewBtn, ridesBtn, completeBtn};

        int y = 100;

        for(JButton b : buttons) {
            b.setBounds(130, y, 220, 45);
            b.setBackground(new Color(52, 152, 219));
            b.setForeground(Color.WHITE);
            b.setFocusPainted(false);
            b.setFont(new Font("Arial", Font.BOLD, 14));
            y += 70;
            frame.add(b);
        }

        frame.add(title);

        frame.setVisible(true);

        // OFFER RIDE
        offerBtn.addActionListener(e -> {

            String source = JOptionPane.showInputDialog(frame, "Enter Source City");
            String sourceArea = JOptionPane.showInputDialog(frame, "Enter Source Area");
            String destination = JOptionPane.showInputDialog(frame, "Enter Destination City");
            String destinationArea = JOptionPane.showInputDialog(frame, "Enter Destination Area");
            String price = JOptionPane.showInputDialog(frame, "Enter Price Per Seat");
            String seats = JOptionPane.showInputDialog(frame, "Enter Available Seats");

            try {
                Connection con = DBConnection.getConnection();

                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT MAX(ride_id)+1 AS next_id FROM RIDE");

                int rideId = 1;

                if(rs.next()) {
                    rideId = rs.getInt("next_id");
                }

                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO RIDE VALUES (?, ?, ?, ?, ?, ?, CURDATE(), CURTIME(), ?, ?, 'Scheduled')"
                );

                ps.setInt(1, rideId);
                ps.setInt(2, driverId);
                ps.setString(3, source);
                ps.setString(4, sourceArea);
                ps.setString(5, destination);
                ps.setString(6, destinationArea);
                ps.setDouble(7, Double.parseDouble(price));
                ps.setInt(8, Integer.parseInt(seats));

                ps.executeUpdate();

                JOptionPane.showMessageDialog(frame,
                    "Ride Offered Successfully\nRide ID: " + rideId);

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // VIEW BOOKINGS
        viewBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps = con.prepareStatement(
                    "SELECT B.booking_id, B.passenger_id, B.seat_booked FROM BOOKING B JOIN RIDE R ON B.ride_id=R.ride_id WHERE R.driver_id=?"
                );

                ps.setInt(1, driverId);

                ResultSet rs = ps.executeQuery();

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(
                        new String[]{"Booking ID","Passenger ID","Seats"},0
                    );

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getInt("passenger_id"),
                        rs.getInt("seat_booked")
                    });
                }

                JTable table = new JTable(model);

                JFrame t = new JFrame("My Bookings");
                t.add(new JScrollPane(table));
                t.setSize(450,300);
                t.setLocationRelativeTo(null);
                t.setVisible(true);

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // MY RIDES
        ridesBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps = con.prepareStatement(
                    "SELECT ride_id, source_city, destination_city, available_seats, ride_status FROM RIDE WHERE driver_id=?"
                );

                ps.setInt(1, driverId);

                ResultSet rs = ps.executeQuery();

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(
                        new String[]{"Ride ID","Source","Destination","Seats","Status"},0
                    );

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("ride_id"),
                        rs.getString("source_city"),
                        rs.getString("destination_city"),
                        rs.getInt("available_seats"),
                        rs.getString("ride_status")
                    });
                }

                JTable table = new JTable(model);

                JFrame t = new JFrame("My Rides");
                t.add(new JScrollPane(table));
                t.setSize(500,300);
                t.setLocationRelativeTo(null);
                t.setVisible(true);

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        // COMPLETE RIDE
        completeBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                PreparedStatement ps = con.prepareStatement(
                    "SELECT ride_id, source_city, destination_city, ride_status FROM RIDE WHERE driver_id=?"
                );

                ps.setInt(1, driverId);

                ResultSet rs = ps.executeQuery();

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(
                        new String[]{"Ride ID","Source","Destination","Status"},0
                    );

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("ride_id"),
                        rs.getString("source_city"),
                        rs.getString("destination_city"),
                        rs.getString("ride_status")
                    });
                }

                JTable table = new JTable(model);

                int option = JOptionPane.showConfirmDialog(
                    frame,
                    new JScrollPane(table),
                    "Select Ride to Complete",
                    JOptionPane.OK_CANCEL_OPTION
                );

                if(option == JOptionPane.OK_OPTION) {
                    int row = table.getSelectedRow();

                    if(row >= 0) {
                        int rideId = (int) table.getValueAt(row, 0);

                        PreparedStatement ps2 = con.prepareStatement(
                            "UPDATE RIDE SET ride_status='Completed' WHERE ride_id=?"
                        );

                        ps2.setInt(1, rideId);
                        ps2.executeUpdate();

                        JOptionPane.showMessageDialog(frame,
                            "Ride Completed Successfully");
                    }
                }

                con.close();

            } catch(Exception ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });
    }
}