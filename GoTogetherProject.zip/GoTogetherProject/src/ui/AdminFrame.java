package ui;

import db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class AdminFrame {

    public AdminFrame() {

        JFrame frame = new JFrame("Admin Dashboard");

        frame.setSize(550, 600);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(245, 247, 250));
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("Admin Dashboard", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(30, 60, 114));
        title.setBounds(120, 20, 300, 35);

        JButton usersBtn = new JButton("View All Users");
        JButton ridesBtn = new JButton("View All Rides");
        JButton driversBtn = new JButton("View Drivers");
        JButton paymentBtn = new JButton("View Payments");

        JButton buttons[] = {
            usersBtn, ridesBtn, driversBtn, paymentBtn
        };

        int y = 100;

        for(JButton b : buttons) {
            b.setBounds(160, y, 220, 50);
            b.setBackground(new Color(52, 152, 219));
            b.setForeground(Color.WHITE);
            b.setFocusPainted(false);
            b.setFont(new Font("Arial", Font.BOLD, 14));
            frame.add(b);
            y += 80;
        }

        frame.add(title);

        // VIEW USERS
        usersBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                String query =
                    "SELECT user_id, first_name, last_name, email, city, overall_rating FROM USER";

                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                String columns[] = {
                    "User ID", "First Name", "Last Name",
                    "Email", "City", "Rating"
                };

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(columns, 0);

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("user_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("city"),
                        rs.getDouble("overall_rating")
                    });
                }

                JTable table = new JTable(model);
                UIHelper.modernTable("All Users", table);

                con.close();

            } catch(Exception ex) {
                UIHelper.modernMessage(frame, ex.getMessage());
            }
        });

        // VIEW RIDES
        ridesBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                String query =
                    "SELECT ride_id, driver_id, source_city, destination_city, ride_status FROM RIDE";

                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                String columns[] = {
                    "Ride ID", "Driver ID", "Source", "Destination", "Status"
                };

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(columns, 0);

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("ride_id"),
                        rs.getInt("driver_id"),
                        rs.getString("source_city"),
                        rs.getString("destination_city"),
                        rs.getString("ride_status")
                    });
                }

                JTable table = new JTable(model);
                UIHelper.modernTable("All Rides", table);

                con.close();

            } catch(Exception ex) {
                UIHelper.modernMessage(frame, ex.getMessage());
            }
        });

        // VIEW DRIVERS
        driversBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                String query =
                    "SELECT D.driver_id, U.first_name, U.last_name, D.license_number, D.driver_rating " +
                    "FROM DRIVER D JOIN USER U ON D.driver_id = U.user_id";

                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                String columns[] = {
                    "Driver ID", "First Name", "Last Name",
                    "License Number", "Driver Rating"
                };

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(columns, 0);

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("driver_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("license_number"),
                        rs.getDouble("driver_rating")
                    });
                }

                JTable table = new JTable(model);

                UIHelper.modernTable("Driver Details", table);

                con.close();

            } catch(Exception ex) {
                UIHelper.modernMessage(frame, ex.getMessage());
            }
        });

        // VIEW PAYMENTS
        paymentBtn.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();

                String query =
                    "SELECT P.payment_id, P.booking_id, P.ride_id, P.payment_status, R.source_city, R.destination_city " +
                    "FROM PAYMENT P JOIN RIDE R ON P.ride_id = R.ride_id";

                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                String columns[] = {
                    "Payment ID", "Booking ID", "Ride ID",
                    "Status", "Source", "Destination"
                };

                javax.swing.table.DefaultTableModel model =
                    new javax.swing.table.DefaultTableModel(columns, 0);

                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("payment_id"),
                        rs.getInt("booking_id"),
                        rs.getInt("ride_id"),
                        rs.getString("payment_status"),
                        rs.getString("source_city"),
                        rs.getString("destination_city")
                    });
                }

                JTable table = new JTable(model);
                UIHelper.modernTable("Payment Details", table);

                con.close();

            } catch(Exception ex) {
                UIHelper.modernMessage(frame, ex.getMessage());
            }
        });

        frame.setVisible(true);
    }
}