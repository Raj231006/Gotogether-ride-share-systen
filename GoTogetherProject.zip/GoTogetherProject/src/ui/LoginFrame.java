package ui;

import db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginFrame {

    public LoginFrame(String role) {

        JFrame frame = new JFrame(role + " Login");

        frame.setSize(500, 400);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(245, 247, 250));
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("Login Page for " + role, SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(30, 60, 114));
        title.setBounds(50, 40, 400, 35);

        JLabel idLabel = new JLabel("Enter " + role + " ID:");
        idLabel.setFont(new Font("Arial", Font.BOLD, 16));
        idLabel.setBounds(70, 140, 180, 30);

        JTextField idField = new JTextField();
        idField.setBounds(250, 140, 140, 38);
        idField.setFont(new Font("Arial", Font.PLAIN, 15));

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(170, 230, 160, 50);
        loginBtn.setBackground(new Color(52, 152, 219));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel msgLabel = new JLabel("");
        msgLabel.setBounds(150, 300, 250, 30);
        msgLabel.setForeground(Color.RED);
        msgLabel.setFont(new Font("Arial", Font.BOLD, 14));

        frame.add(title);
        frame.add(idLabel);
        frame.add(idField);
        frame.add(loginBtn);
        frame.add(msgLabel);

        Runnable loginAction = () -> {

            try {
                int id = Integer.parseInt(idField.getText());

                Connection con = DBConnection.getConnection();

                String query = "";

                if(role.equals("Driver")) {
                    query = "SELECT * FROM DRIVER WHERE driver_id=?";
                }
                else if(role.equals("Passenger")) {
                    query = "SELECT * FROM PASSENGER WHERE passenger_id=?";
                }
                else {
                    query = "SELECT * FROM ADMIN WHERE admin_id=?";
                }

                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, id);

                ResultSet rs = ps.executeQuery();

                if(rs.next()) {

                    frame.dispose();

                    if(role.equals("Driver")) {
                        new DriverFrame(id);
                    }
                    else if(role.equals("Passenger")) {
                        new PassengerFrame(id);
                    }
                    else {
                        new AdminFrame();
                    }

                } else {
                    msgLabel.setText("Login Failed: Invalid ID");
                }

                con.close();

            } catch(Exception ex) {
                msgLabel.setText("Login Failed: Invalid Input");
            }
        };

        loginBtn.addActionListener(e -> loginAction.run());

        idField.addActionListener(e -> loginAction.run());

        frame.setVisible(true);
    }
}