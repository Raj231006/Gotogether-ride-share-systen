package service;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class BookingService {

    public static void bookRide(Scanner sc) {

        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Enter Booking ID: ");
            int bookingId = sc.nextInt();

            System.out.print("Enter Passenger ID: ");
            int passengerId = sc.nextInt();

            System.out.print("Enter Ride ID: ");
            int rideId = sc.nextInt();

            System.out.print("Enter Seats Booked: ");
            int seats = sc.nextInt();

            double totalAmount = seats * 200;

            String query = "INSERT INTO BOOKING VALUES (?, ?, ?, ?, CURDATE(), 'Confirmed', ?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, bookingId);
            ps.setInt(2, passengerId);
            ps.setInt(3, rideId);
            ps.setInt(4, seats);
            ps.setDouble(5, totalAmount);

            int rows = ps.executeUpdate();

            if(rows > 0) {
                System.out.println("Booking Successful");
            }

            con.close();

        } catch(Exception e) {
            System.out.println("Booking Failed: " + e.getMessage());
        }
    }

    public static void cancelBooking(Scanner sc) {

        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Enter Booking ID to cancel: ");
            int bookingId = sc.nextInt();

            String query = "UPDATE BOOKING SET booking_status='Cancelled' WHERE booking_id=?";

            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, bookingId);

            int rows = ps.executeUpdate();

            if(rows > 0) {
                System.out.println("Booking Cancelled Successfully");
            }

            con.close();

        } catch(Exception e) {
            System.out.println("Cancel Failed: " + e.getMessage());
        }
    }
}
