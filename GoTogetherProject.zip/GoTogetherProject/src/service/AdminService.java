package service;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminService {

    public static void viewAllUsers() {

        try {
            Connection con = DBConnection.getConnection();

            String query = "SELECT user_id, first_name, last_name, email, city FROM USER";

            PreparedStatement ps = con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n===== All Users =====");

            while(rs.next()) {
                System.out.println(
                    "User ID: " + rs.getInt("user_id") +
                    " Name: " + rs.getString("first_name") + " " +
                    rs.getString("last_name") +
                    " Email: " + rs.getString("email") +
                    " City: " + rs.getString("city")
                );
            }

            con.close();

        } catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void viewAllRides() {

        try {
            Connection con = DBConnection.getConnection();

            String query = "SELECT ride_id, source_city, destination_city, available_seats, ride_status FROM RIDE";

            PreparedStatement ps = con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n===== All Rides =====");

            while(rs.next()) {
                System.out.println(
                    "Ride ID: " + rs.getInt("ride_id") +
                    " Source: " + rs.getString("source_city") +
                    " Destination: " + rs.getString("destination_city") +
                    " Seats: " + rs.getInt("available_seats") +
                    " Status: " + rs.getString("ride_status")
                );
            }

            con.close();

        } catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
