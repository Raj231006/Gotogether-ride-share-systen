package service;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class DriverService {

    public static void viewBookings(Scanner sc) {

        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Enter Ride ID: ");
            int rideId = sc.nextInt();

            String query = "SELECT booking_id, passenger_id, seat_booked, booking_status FROM BOOKING WHERE ride_id=?";

            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, rideId);

            ResultSet rs = ps.executeQuery();

            boolean found = false;

            while(rs.next()) {
                found = true;

                System.out.println(
                    "Booking ID: " + rs.getInt("booking_id") +
                    " Passenger: " + rs.getInt("passenger_id") +
                    " Seats: " + rs.getInt("seat_booked") +
                    " Status: " + rs.getString("booking_status")
                );
            }

            if(!found) {
                System.out.println("No bookings found");
            }

            con.close();

        } catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

