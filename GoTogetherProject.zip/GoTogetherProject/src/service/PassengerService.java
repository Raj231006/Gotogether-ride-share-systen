
package service;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class PassengerService {

    public static void searchRides(Scanner sc) {

        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Enter Source City: ");
            String source = sc.next();

            String query = "SELECT ride_id, destination_city, available_seats, price_per_seats FROM RIDE WHERE source_city=?";

            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, source);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                System.out.println(
                    "Ride ID: " + rs.getInt("ride_id") +
                    " Destination: " + rs.getString("destination_city") +
                    " Seats: " + rs.getInt("available_seats") +
                    " Price: " + rs.getDouble("price_per_seats")
                );
            }

            con.close();

        } catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void viewRideHistory(Scanner sc) {

        try {
            Connection con = DBConnection.getConnection();

            System.out.print("Enter Passenger ID: ");
            int passengerId = sc.nextInt();

            String query = "SELECT booking_id, ride_id, booking_status FROM BOOKING WHERE passenger_id=?";

            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, passengerId);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                System.out.println(
                    "Booking ID: " + rs.getInt("booking_id") +
                    " Ride ID: " + rs.getInt("ride_id") +
                    " Status: " + rs.getString("booking_status")
                );
            }

            con.close();

        } catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}