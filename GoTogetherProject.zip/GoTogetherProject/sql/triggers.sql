/* trigger 1 Reduce seat after booking*/
DELIMITER //

CREATE TRIGGER reduce_seats_after_booking
AFTER INSERT ON BOOKING
FOR EACH ROW
BEGIN
    UPDATE RIDE
    SET available_seats = available_seats - NEW.seat_booked
    WHERE ride_id = NEW.ride_id;
END;
//

/* trigger 2 Check seats Before Booking*/
CREATE TRIGGER check_seats_before_booking
BEFORE INSERT ON BOOKING
FOR EACH ROW
BEGIN
    DECLARE seats INT;

    SELECT available_seats INTO seats
    FROM RIDE
    WHERE ride_id = NEW.ride_id;

    IF NEW.seat_booked > seats THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seats not available';
    END IF;
END;
//

/* trigger 3 Restore seats after Booking cancel*/
CREATE TRIGGER restore_seats_after_cancel
AFTER UPDATE ON BOOKING
FOR EACH ROW
BEGIN
    IF NEW.booking_status = 'Cancelled' AND OLD.booking_status = 'Confirmed' THEN
        UPDATE RIDE
        SET available_seats = available_seats + OLD.seat_booked
        WHERE ride_id = OLD.ride_id;
    END IF;
END;
//

DELIMITER ;